<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel ="stylesheet" type ="text/css" href="bootstrap.min.css">
        <script src="jquery-3.3.1.min.js"></script>
        <script type = text/javascript src="bootstrap.min.js"></script>


        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>



</head>
<body>


  <!-- Start Nagigation -->
  <?php include "navigationbar1.php"; ?>
  <!-- End Navigation -->
    
    
    
    
    
    
    
    
    
    
    
    

<div class="container" style = "margin-top : 100px">
      <h2 class = text-center style = "font-family : 'Monotype Corsiva' ; color : #E6120E">Contact Us</h2>
      <div class="row">
          <div class="col-sm-4">
              <img src="myimages/1.jpg" width=300 height = 500 class="img-responsive">        
          </div>
          <div class="col-sm-8" style = "font-size : 30pt">
             <p>Name : Pratiksha Ganpat Kolekar</p>
			 <p>Contact: 7089787645</p>
			 <p>Address : pune</p>
			 
			 
			 
          </div>
      </div>
  </div>
  

</body>
</html>
